# Ebook Reader (Android)

Aplikasi baca ebook Android dengan Kotlin + Jetpack Compose. Mendukung **EPUB, PDF, dan TXT**, dilengkapi perpustakaan buku, bookmark, mode malam, dan **fitur terjemahan on-device** (Google ML Kit, gratis, tanpa API key).

## Fitur
- **Perpustakaan**: import buku dari penyimpanan lewat Storage Access Framework, daftar buku, hapus buku
- **Reader**:
  - EPUB & TXT: ditampilkan sebagai teks yang bisa di-scroll (parser EPUB custom, tanpa library eksternal)
  - PDF: dirender per halaman memakai `android.graphics.pdf.PdfRenderer` bawaan Android
- **Bookmark**: disimpan per buku di database Room (SQLite)
- **Mode malam**: toggle di layar reader (tema sepia untuk siang, gelap untuk malam)
- **Terjemahan**: salin teks dari halaman → tempel di panel terjemahan → pilih bahasa tujuan. Memakai Google ML Kit Translate, model bahasa diunduh otomatis sekali (butuh internet), setelahnya bisa offline
- **Rekomendasi & Novel Terbaik** (tab baru di bottom navigation):
  - *Trending Hari Ini* — dari API publik **Open Library** (openlibrary.org), tap untuk buka detail di browser
  - *Novel Klasik Terbaik — Domain Publik* — dari **Project Gutenberg** (via API Gutendex), semuanya buku domain publik yang 100% legal diunduh gratis; tombol **+** langsung mengunduh EPUB-nya ke perpustakaan lokal
  - Catatan: fitur ini sengaja hanya memakai sumber resmi/legal. Saya tidak menambahkan integrasi ke situs pembajakan buku (mis. Z-Library) karena itu melanggar hak cipta

## Struktur Proyek
```
EbookReaderApp/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── res/values/themes.xml
│       └── java/com/ebookreader/app/
│           ├── MainActivity.kt
│           ├── navigation/      # Navigasi Compose
│           ├── data/            # Room: Entity, DAO, Database
│           ├── repository/      # Repository pola MVVM
│           ├── viewmodel/       # LibraryViewModel, ReaderViewModel
│           ├── ui/              # LibraryScreen, ReaderScreen, tema
│           ├── parser/          # EpubParser, PdfPageRenderer
│           ├── translate/       # TranslationHelper (ML Kit)
│           ├── discover/        # DiscoverApi (Open Library, Project Gutenberg)
│           └── utils/           # FileImporter (SAF)
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## Menjalankan di Android Studio
1. Ekstrak zip ini, buka foldernya di **Android Studio** (versi Koala/2024.1 atau lebih baru).
2. Android Studio akan menawarkan membuat **Gradle Wrapper** otomatis saat sync pertama (karena file wrapper biner tidak disertakan di zip ini) — terima saja, atau jalankan `gradle wrapper` jika Gradle sudah terpasang di komputer kamu.
3. Tunggu Gradle sync selesai mengunduh dependency.
4. Jalankan (Run ▶) di emulator atau perangkat Android 7.0 (API 24) ke atas.

## Push ke GitHub
Saya tidak punya akses internet untuk membuat/push repo GitHub secara langsung dari sini, jadi lakukan langkah ini dari komputermu setelah mengekstrak zip:

1. Buat repo kosong baru di https://github.com/new (jangan centang "Initialize with README").
2. Di terminal, masuk ke folder proyek lalu jalankan:

```bash
cd EbookReaderApp
git init
git add .
git commit -m "Initial commit: Ebook Reader Android app"
git branch -M main
git remote add origin https://github.com/USERNAME/NAMA-REPO.git
git push -u origin main
```

Ganti `USERNAME` dan `NAMA-REPO` dengan milikmu.

## Izin yang Digunakan
- `INTERNET`: dipakai untuk (1) mengunduh model bahasa fitur terjemahan sekali di awal, dan (2) memuat daftar rekomendasi buku dari Open Library & Project Gutenberg. Tidak ada tracking atau komunikasi lain ke server manapun.

## Keterbatasan & Ide Pengembangan Lanjutan
- **Format Kindle (MOBI/AZW3)** belum didukung — formatnya proprietary dan tidak ada parser open-source yang stabil untuk Android. Bisa ditambahkan dengan library pihak ketiga bila dibutuhkan.
- Parser EPUB bersifat ringan (custom, tanpa library) — cukup untuk EPUB standar, namun belum menangani seluruh kasus EPUB3 kompleks atau EPUB berproteksi DRM.
- Terjemahan saat ini berbasis **salin-tempel manual**, bukan "pilih teks → muncul tombol terjemahan" otomatis, karena Jetpack Compose belum memiliki API resmi yang stabil untuk custom context-menu pada `SelectionContainer`. Bisa dikembangkan lebih lanjut dengan `TextToolbar` custom.
- Posisi baca terakhir sudah disimpan di database, tapi auto-scroll ke posisi terakhir saat membuka ulang buku belum diimplementasikan — bisa ditambahkan di `ReaderScreen`.
- Ikon aplikasi memakai ikon default sistem (tidak disertakan aset `mipmap` kustom) — tambahkan ikonmu sendiri lewat Image Asset Studio di Android Studio.
