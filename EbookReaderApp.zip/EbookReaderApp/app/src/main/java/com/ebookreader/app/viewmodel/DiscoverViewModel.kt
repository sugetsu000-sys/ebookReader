package com.ebookreader.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ebookreader.app.data.AppDatabase
import com.ebookreader.app.data.BookEntity
import com.ebookreader.app.discover.DiscoverApi
import com.ebookreader.app.discover.DiscoverBook
import com.ebookreader.app.parser.EpubParser
import com.ebookreader.app.repository.BookRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.URL

class DiscoverViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = BookRepository(AppDatabase.getInstance(application))

    private val _trending = MutableStateFlow<List<DiscoverBook>>(emptyList())
    val trending: StateFlow<List<DiscoverBook>> = _trending.asStateFlow()

    private val _publicDomain = MutableStateFlow<List<DiscoverBook>>(emptyList())
    val publicDomain: StateFlow<List<DiscoverBook>> = _publicDomain.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _downloadingTitle = MutableStateFlow<String?>(null)
    val downloadingTitle: StateFlow<String?> = _downloadingTitle.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _isLoading.value = true
            _trending.value = DiscoverApi.fetchTrending()
            _publicDomain.value = DiscoverApi.fetchPopularPublicDomain()
            _isLoading.value = false
        }
    }

    /** Unduh buku domain publik (legal, dari Project Gutenberg) langsung ke perpustakaan lokal. */
    fun addPublicDomainBookToLibrary(book: DiscoverBook) {
        val url = book.downloadEpubUrl ?: return
        viewModelScope.launch {
            _downloadingTitle.value = book.title
            runCatching {
                val destFile = withContext(Dispatchers.IO) {
                    val booksDir = File(getApplication<Application>().filesDir, "books").apply { mkdirs() }
                    val safeName = book.title.take(40).filter { it.isLetterOrDigit() }.ifBlank { "buku" }
                    val file = File(booksDir, "${System.currentTimeMillis()}_$safeName.epub")
                    URL(url).openStream().use { input -> file.outputStream().use { output -> input.copyTo(output) } }
                    file
                }
                var title = book.title
                var author = book.author
                runCatching {
                    val meta = EpubParser.readMetadata(destFile)
                    if (meta.title.isNotBlank()) title = meta.title
                    if (meta.author.isNotBlank()) author = meta.author
                }
                repository.insertBook(
                    BookEntity(title = title, author = author, filePath = destFile.absolutePath, format = "epub")
                )
            }
            _downloadingTitle.value = null
        }
    }
}
