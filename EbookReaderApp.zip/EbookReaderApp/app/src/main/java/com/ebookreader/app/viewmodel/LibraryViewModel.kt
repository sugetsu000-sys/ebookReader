package com.ebookreader.app.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ebookreader.app.data.AppDatabase
import com.ebookreader.app.data.BookEntity
import com.ebookreader.app.repository.BookRepository
import com.ebookreader.app.utils.FileImporter
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class LibraryViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = BookRepository(AppDatabase.getInstance(application))

    val books: StateFlow<List<BookEntity>> = repository.getAllBooks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun importBook(uri: Uri) {
        viewModelScope.launch {
            val imported = FileImporter.importBook(getApplication(), uri) ?: return@launch
            repository.insertBook(
                BookEntity(
                    title = imported.title,
                    author = imported.author,
                    filePath = imported.filePath,
                    format = imported.format
                )
            )
        }
    }

    fun deleteBook(book: BookEntity) {
        viewModelScope.launch { repository.deleteBook(book) }
    }
}
