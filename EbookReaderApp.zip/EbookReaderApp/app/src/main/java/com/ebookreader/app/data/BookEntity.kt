package com.ebookreader.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "books")
data class BookEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val author: String = "Tidak diketahui",
    val filePath: String,
    val format: String, // "epub", "pdf", "txt"
    val lastPosition: Int = 0,
    val lastPageIndex: Int = 0,
    val dateAdded: Long = System.currentTimeMillis(),
    val lastOpened: Long = 0
)
