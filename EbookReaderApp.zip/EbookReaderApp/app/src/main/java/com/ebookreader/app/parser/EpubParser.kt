package com.ebookreader.app.parser

import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.File
import java.util.zip.ZipFile

/**
 * Parser EPUB sederhana tanpa dependency eksternal.
 * Membaca META-INF/container.xml untuk menemukan file OPF,
 * lalu membaca metadata (judul/penulis) dan urutan spine (daftar bab).
 */
object EpubParser {

    data class Metadata(val title: String, val author: String)
    data class Chapter(val id: String, val href: String)

    private fun newParser(): XmlPullParser {
        val factory = XmlPullParserFactory.newInstance()
        factory.isNamespaceAware = false
        return factory.newPullParser()
    }

    private fun findOpfPath(zip: ZipFile): String {
        val containerEntry = zip.getEntry("META-INF/container.xml")
            ?: throw IllegalStateException("container.xml tidak ditemukan di dalam EPUB")
        val parser = newParser()
        parser.setInput(zip.getInputStream(containerEntry), "UTF-8")
        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_TAG && parser.name == "rootfile") {
                return parser.getAttributeValue(null, "full-path")
                    ?: throw IllegalStateException("Atribut full-path tidak ditemukan")
            }
            eventType = parser.next()
        }
        throw IllegalStateException("Elemen rootfile OPF tidak ditemukan")
    }

    fun readMetadata(file: File): Metadata {
        ZipFile(file).use { zip ->
            val opfPath = findOpfPath(zip)
            val opfEntry = zip.getEntry(opfPath) ?: throw IllegalStateException("File OPF tidak ditemukan")
            val parser = newParser()
            parser.setInput(zip.getInputStream(opfEntry), "UTF-8")

            var title = ""
            var author = ""
            var currentTag = ""
            var eventType = parser.eventType
            while (eventType != XmlPullParser.END_DOCUMENT) {
                when (eventType) {
                    XmlPullParser.START_TAG -> currentTag = parser.name
                    XmlPullParser.TEXT -> {
                        val text = parser.text?.trim().orEmpty()
                        if (text.isNotEmpty()) {
                            if (currentTag.endsWith("title") && title.isEmpty()) title = text
                            if (currentTag.endsWith("creator") && author.isEmpty()) author = text
                        }
                    }
                }
                eventType = parser.next()
            }
            return Metadata(title, author)
        }
    }

    /** Mengembalikan pasangan (folder OPF, daftar chapter sesuai urutan spine). */
    fun readSpine(file: File): Pair<String, List<Chapter>> {
        ZipFile(file).use { zip ->
            val opfPath = findOpfPath(zip)
            val opfDir = opfPath.substringBeforeLast('/', "")
            val opfEntry = zip.getEntry(opfPath)!!
            val parser = newParser()
            parser.setInput(zip.getInputStream(opfEntry), "UTF-8")

            val manifest = mutableMapOf<String, String>() // id -> href
            val spineIds = mutableListOf<String>()

            var eventType = parser.eventType
            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG) {
                    when (parser.name) {
                        "item" -> {
                            val id = parser.getAttributeValue(null, "id")
                            val href = parser.getAttributeValue(null, "href")
                            if (id != null && href != null) manifest[id] = href
                        }
                        "itemref" -> {
                            val idref = parser.getAttributeValue(null, "idref")
                            if (idref != null) spineIds.add(idref)
                        }
                    }
                }
                eventType = parser.next()
            }

            val chapters = spineIds.mapNotNull { id ->
                manifest[id]?.let { href -> Chapter(id, if (opfDir.isEmpty()) href else "$opfDir/$href") }
            }
            return opfDir to chapters
        }
    }

    /** Membaca satu file bab HTML/XHTML dan mengembalikannya sebagai teks polos. */
    fun readChapterText(file: File, href: String): String {
        ZipFile(file).use { zip ->
            val entry = zip.getEntry(href) ?: return ""
            val html = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).readText()
            return htmlToPlainText(html)
        }
    }

    private fun htmlToPlainText(html: String): String {
        var text = html
            .replace(Regex("(?is)<script.*?</script>"), "")
            .replace(Regex("(?is)<style.*?</style>"), "")
            .replace(Regex("(?i)<br\\s*/?>"), "\n")
            .replace(Regex("(?i)</p>"), "\n\n")
            .replace(Regex("<[^>]+>"), "")
        text = text
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
        return text.trim()
    }
}
