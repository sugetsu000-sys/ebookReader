package com.ebookreader.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ebookreader.app.parser.PdfPageRenderer
import com.ebookreader.app.translate.TranslationHelper
import com.ebookreader.app.ui.theme.EbookReaderTheme
import com.ebookreader.app.viewmodel.ReaderViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(bookId: Long, onBack: () -> Unit, viewModel: ReaderViewModel = viewModel()) {
    val book by viewModel.book.collectAsState()
    val chapterTexts by viewModel.chapterTexts.collectAsState()
    val translatedText by viewModel.translatedText.collectAsState()
    val isTranslating by viewModel.isTranslating.collectAsState()

    var darkMode by remember { mutableStateOf(false) }
    var translateInput by remember { mutableStateOf("") }
    var showTranslatePanel by remember { mutableStateOf(false) }
    var targetLang by remember { mutableStateOf("Indonesia") }

    LaunchedEffect(bookId) { viewModel.loadBook(bookId) }

    EbookReaderTheme(darkTheme = darkMode) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(book?.title ?: "Membaca") },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                        }
                    },
                    actions = {
                        IconButton(onClick = { darkMode = !darkMode }) {
                            Icon(
                                if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = "Mode malam"
                            )
                        }
                        IconButton(onClick = { viewModel.addBookmark(position = 0, pageIndex = 0, label = "Bookmark") }) {
                            Icon(Icons.Default.Bookmark, contentDescription = "Tandai halaman")
                        }
                        IconButton(onClick = { showTranslatePanel = !showTranslatePanel }) {
                            Icon(Icons.Default.Translate, contentDescription = "Terjemahkan")
                        }
                    }
                )
            },
            bottomBar = {
                if (showTranslatePanel) {
                    TranslatePanel(
                        input = translateInput,
                        onInputChange = { translateInput = it },
                        targetLang = targetLang,
                        onTargetLangChange = { targetLang = it },
                        isTranslating = isTranslating,
                        result = translatedText,
                        onTranslate = {
                            val code = TranslationHelper.supportedLanguages[targetLang] ?: "id"
                            viewModel.translateSelection(translateInput, sourceLang = "en", targetLang = code)
                        }
                    )
                }
            }
        ) { padding ->
            when (book?.format) {
                "pdf" -> PdfReaderBody(filePath = book!!.filePath, modifier = Modifier.padding(padding))
                else -> SelectionContainer {
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                        items(chapterTexts) { chapter ->
                            Text(text = chapter, modifier = Modifier.padding(bottom = 24.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TranslatePanel(
    input: String,
    onInputChange: (String) -> Unit,
    targetLang: String,
    onTargetLangChange: (String) -> Unit,
    isTranslating: Boolean,
    result: String?,
    onTranslate: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Surface(tonalElevation = 4.dp) {
        Column(Modifier.padding(12.dp)) {
            Text(
                "Salin teks dari halaman (tahan untuk menyalin), lalu tempel di sini untuk menerjemahkan:",
                style = MaterialTheme.typography.labelMedium
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = onInputChange,
                    label = { Text("Teks") },
                    modifier = Modifier.weight(1f),
                    maxLines = 3
                )
                Spacer(Modifier.width(8.dp))
                Box {
                    AssistChip(onClick = { expanded = true }, label = { Text(targetLang) })
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        TranslationHelper.supportedLanguages.keys.forEach { lang ->
                            DropdownMenuItem(text = { Text(lang) }, onClick = {
                                onTargetLangChange(lang)
                                expanded = false
                            })
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onTranslate, enabled = input.isNotBlank() && !isTranslating) {
                Text(if (isTranslating) "Menerjemahkan..." else "Terjemahkan")
            }
            result?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun PdfReaderBody(filePath: String, modifier: Modifier = Modifier) {
    var pageIndex by remember { mutableStateOf(0) }
    var pageCount by remember { mutableStateOf(0) }
    var bitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }

    val density = LocalDensity.current
    val screenWidthDp = LocalConfiguration.current.screenWidthDp
    val widthPx = with(density) { screenWidthDp.dp.roundToPx() }

    LaunchedEffect(filePath, pageIndex) {
        runCatching {
            PdfPageRenderer(File(filePath)).use { renderer ->
                pageCount = renderer.pageCount
                bitmap = renderer.renderPage(pageIndex.coerceIn(0, (pageCount - 1).coerceAtLeast(0)), widthPx)
            }
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            bitmap?.let {
                Image(bitmap = it.asImageBitmap(), contentDescription = "Halaman ${pageIndex + 1}")
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(onClick = { if (pageIndex > 0) pageIndex-- }, enabled = pageIndex > 0) { Text("Sebelumnya") }
            Text("Halaman ${pageIndex + 1} / $pageCount")
            Button(onClick = { if (pageIndex < pageCount - 1) pageIndex++ }, enabled = pageIndex < pageCount - 1) { Text("Berikutnya") }
        }
    }
}
