package com.ebookreader.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ebookreader.app.viewmodel.LibraryViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(onOpenBook: (Long) -> Unit, viewModel: LibraryViewModel = viewModel()) {
    val books by viewModel.books.collectAsState()

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.importBook(it) }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Perpustakaan Saya") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                filePicker.launch(arrayOf("application/epub+zip", "application/pdf", "text/plain"))
            }) {
                Icon(Icons.Default.Add, contentDescription = "Tambah buku")
            }
        }
    ) { padding ->
        if (books.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Belum ada buku. Tekan + untuk menambah EPUB, PDF, atau TXT.")
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
                items(books, key = { it.id }) { book ->
                    ListItem(
                        headlineContent = { Text(book.title) },
                        supportingContent = { Text("${book.author} • ${book.format.uppercase()}") },
                        trailingContent = {
                            IconButton(onClick = { viewModel.deleteBook(book) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Hapus")
                            }
                        },
                        modifier = Modifier.clickable { onOpenBook(book.id) }
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}
