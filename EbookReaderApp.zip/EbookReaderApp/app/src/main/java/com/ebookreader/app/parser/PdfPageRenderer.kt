package com.ebookreader.app.parser

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.File

/** Pembungkus di atas android.graphics.pdf.PdfRenderer bawaan Android (API 21+). */
class PdfPageRenderer(file: File) : AutoCloseable {
    private val fileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(fileDescriptor)

    val pageCount: Int get() = renderer.pageCount

    fun renderPage(index: Int, widthPx: Int): Bitmap {
        renderer.openPage(index).use { page ->
            val scale = widthPx.toFloat() / page.width
            val heightPx = (page.height * scale).toInt().coerceAtLeast(1)
            val bitmap = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888)
            bitmap.eraseColor(Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bitmap
        }
    }

    override fun close() {
        renderer.close()
        fileDescriptor.close()
    }
}
