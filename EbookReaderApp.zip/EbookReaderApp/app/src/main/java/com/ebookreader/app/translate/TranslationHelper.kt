package com.ebookreader.app.translate

import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Terjemahan teks on-device memakai Google ML Kit Translate.
 * Model bahasa diunduh otomatis sekali (butuh internet), setelah itu bisa bekerja offline.
 * Tidak perlu API key.
 */
object TranslationHelper {

    suspend fun translate(text: String, sourceLang: String, targetLang: String): String {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(sourceLang)
            .setTargetLanguage(targetLang)
            .build()
        val translator = Translation.getClient(options)
        return try {
            downloadModelIfNeeded(translator)
            translateText(translator, text)
        } finally {
            translator.close()
        }
    }

    private suspend fun downloadModelIfNeeded(translator: Translator) =
        suspendCancellableCoroutine<Unit> { cont ->
            translator.downloadModelIfNeeded()
                .addOnSuccessListener { cont.resume(Unit) }
                .addOnFailureListener { cont.resumeWithException(it) }
        }

    private suspend fun translateText(translator: Translator, text: String) =
        suspendCancellableCoroutine<String> { cont ->
            translator.translate(text)
                .addOnSuccessListener { cont.resume(it) }
                .addOnFailureListener { cont.resumeWithException(it) }
        }

    /** Bahasa umum yang didukung ML Kit; tambahkan sendiri dari TranslateLanguage jika perlu. */
    val supportedLanguages: Map<String, String> = linkedMapOf(
        "Indonesia" to TranslateLanguage.INDONESIAN,
        "Inggris" to TranslateLanguage.ENGLISH,
        "Mandarin" to TranslateLanguage.CHINESE,
        "Jepang" to TranslateLanguage.JAPANESE,
        "Arab" to TranslateLanguage.ARABIC,
        "Spanyol" to TranslateLanguage.SPANISH,
        "Prancis" to TranslateLanguage.FRENCH,
        "Jerman" to TranslateLanguage.GERMAN,
        "Korea" to TranslateLanguage.KOREAN
    )
}
