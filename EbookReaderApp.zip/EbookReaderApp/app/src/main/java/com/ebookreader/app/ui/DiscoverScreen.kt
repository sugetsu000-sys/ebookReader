package com.ebookreader.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.ebookreader.app.discover.DiscoverBook
import com.ebookreader.app.viewmodel.DiscoverViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiscoverScreen(onAddedToLibrary: () -> Unit = {}, viewModel: DiscoverViewModel = viewModel()) {
    val trending by viewModel.trending.collectAsState()
    val publicDomain by viewModel.publicDomain.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val downloadingTitle by viewModel.downloadingTitle.collectAsState()
    val context = LocalContext.current

    Scaffold(topBar = { TopAppBar(title = { Text("Rekomendasi & Novel Terbaik") }) }) { padding ->
        if (isLoading && trending.isEmpty() && publicDomain.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(bottom = 24.dp)) {
                item {
                    SectionHeader("🔥 Trending Hari Ini")
                    Text(
                        "Sumber: Open Library",
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(trending) { book ->
                            TrendingCard(book) {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(book.detailUrl)))
                            }
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                }
                item {
                    SectionHeader("📚 Novel Klasik Terbaik — Domain Publik")
                    Text(
                        "Gratis & legal, langsung dari Project Gutenberg",
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                }
                items(publicDomain) { book ->
                    PublicDomainRow(
                        book = book,
                        isDownloading = downloadingTitle == book.title,
                        onAdd = {
                            viewModel.addPublicDomainBookToLibrary(book)
                            onAddedToLibrary()
                        },
                        onOpenDetail = {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(book.detailUrl)))
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
}

@Composable
private fun TrendingCard(book: DiscoverBook, onClick: () -> Unit) {
    Column(modifier = Modifier.width(120.dp).clickable { onClick() }) {
        AsyncImage(
            model = book.coverUrl,
            contentDescription = book.title,
            modifier = Modifier.width(120.dp).height(170.dp).clip(RoundedCornerShape(8.dp)),
            contentScale = ContentScale.Crop
        )
        Spacer(Modifier.height(4.dp))
        Text(book.title, style = MaterialTheme.typography.bodySmall, maxLines = 2)
        Text(book.author, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

@Composable
private fun PublicDomainRow(book: DiscoverBook, isDownloading: Boolean, onAdd: () -> Unit, onOpenDetail: () -> Unit) {
    ListItem(
        headlineContent = { Text(book.title) },
        supportingContent = { Text("${book.author} • ${book.source}") },
        leadingContent = {
            AsyncImage(
                model = book.coverUrl,
                contentDescription = book.title,
                modifier = Modifier.width(40.dp).height(56.dp).clip(RoundedCornerShape(4.dp)),
                contentScale = ContentScale.Crop
            )
        },
        trailingContent = {
            Row {
                IconButton(onClick = onOpenDetail) {
                    Icon(Icons.Default.OpenInBrowser, contentDescription = "Buka detail")
                }
                if (book.downloadEpubUrl != null) {
                    IconButton(onClick = onAdd, enabled = !isDownloading) {
                        if (isDownloading) {
                            CircularProgressIndicator(modifier = Modifier.width(20.dp).height(20.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Add, contentDescription = "Tambah ke perpustakaan")
                        }
                    }
                }
            }
        }
    )
    HorizontalDivider()
}
