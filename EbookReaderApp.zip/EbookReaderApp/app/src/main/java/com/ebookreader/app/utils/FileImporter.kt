package com.ebookreader.app.utils

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.ebookreader.app.parser.EpubParser
import java.io.File

object FileImporter {

    data class ImportedBook(val title: String, val author: String, val filePath: String, val format: String)

    /** Menyalin file yang dipilih user (via SAF) ke penyimpanan internal app, lalu membaca metadatanya. */
    fun importBook(context: Context, uri: Uri): ImportedBook? {
        val displayName = getDisplayName(context, uri) ?: "Untitled"
        val extension = displayName.substringAfterLast('.', "").lowercase()
        val format = when (extension) {
            "epub" -> "epub"
            "pdf" -> "pdf"
            "txt" -> "txt"
            else -> return null
        }

        val booksDir = File(context.filesDir, "books").apply { mkdirs() }
        val destFile = File(booksDir, "${System.currentTimeMillis()}_$displayName")

        context.contentResolver.openInputStream(uri)?.use { input ->
            destFile.outputStream().use { output -> input.copyTo(output) }
        } ?: return null

        var title = displayName.substringBeforeLast('.')
        var author = "Tidak diketahui"

        if (format == "epub") {
            runCatching {
                val meta = EpubParser.readMetadata(destFile)
                if (meta.title.isNotBlank()) title = meta.title
                if (meta.author.isNotBlank()) author = meta.author
            }
        }

        return ImportedBook(title, author, destFile.absolutePath, format)
    }

    private fun getDisplayName(context: Context, uri: Uri): String? {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIndex >= 0) return cursor.getString(nameIndex)
        }
        return uri.lastPathSegment
    }
}
