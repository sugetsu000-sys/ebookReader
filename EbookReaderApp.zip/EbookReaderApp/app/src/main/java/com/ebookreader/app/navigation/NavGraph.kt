package com.ebookreader.app.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.ebookreader.app.ui.HomeScreen
import com.ebookreader.app.ui.ReaderScreen

@Composable
fun AppNavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(onOpenBook = { bookId ->
                navController.navigate("reader/$bookId")
            })
        }
        composable("reader/{bookId}") { backStackEntry ->
            val bookId = backStackEntry.arguments?.getString("bookId")?.toLongOrNull()
            if (bookId != null) {
                ReaderScreen(bookId = bookId, onBack = { navController.popBackStack() })
            }
        }
    }
}
