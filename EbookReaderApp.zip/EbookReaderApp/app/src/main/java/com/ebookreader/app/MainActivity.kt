package com.ebookreader.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.ebookreader.app.navigation.AppNavGraph
import com.ebookreader.app.ui.theme.EbookReaderTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EbookReaderTheme {
                AppNavGraph()
            }
        }
    }
}
