package com.ebookreader.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    val position: Int,
    val pageIndex: Int = 0,
    val label: String,
    val dateCreated: Long = System.currentTimeMillis()
)
