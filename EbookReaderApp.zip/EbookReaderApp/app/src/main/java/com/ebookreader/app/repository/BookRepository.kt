package com.ebookreader.app.repository

import com.ebookreader.app.data.AppDatabase
import com.ebookreader.app.data.BookEntity
import com.ebookreader.app.data.BookmarkEntity

class BookRepository(private val db: AppDatabase) {
    fun getAllBooks() = db.bookDao().getAllBooks()
    suspend fun getBook(id: Long) = db.bookDao().getBook(id)
    suspend fun insertBook(book: BookEntity) = db.bookDao().insertBook(book)
    suspend fun updateBook(book: BookEntity) = db.bookDao().updateBook(book)
    suspend fun deleteBook(book: BookEntity) = db.bookDao().deleteBook(book)
    fun getBookmarks(bookId: Long) = db.bookDao().getBookmarks(bookId)
    suspend fun addBookmark(bookmark: BookmarkEntity) = db.bookDao().insertBookmark(bookmark)
    suspend fun deleteBookmark(bookmark: BookmarkEntity) = db.bookDao().deleteBookmark(bookmark)
}
