package com.ebookreader.app.discover

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class DiscoverBook(
    val title: String,
    val author: String,
    val coverUrl: String?,
    val source: String,
    val detailUrl: String,
    /** Hanya terisi untuk buku domain publik yang boleh diunduh langsung secara legal. */
    val downloadEpubUrl: String? = null
)

/**
 * Sumber rekomendasi & daftar buku terbaik, semuanya dari API publik yang legal:
 * - Open Library (openlibrary.org) untuk buku trending
 * - Project Gutenberg via Gutendex (gutendex.com) untuk novel klasik domain publik
 * Tidak ada scraping atau akses ke situs pembajakan.
 */
object DiscoverApi {

    private fun fetchJson(urlString: String): String {
        val connection = URL(urlString).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.setRequestProperty("User-Agent", "EbookReaderApp/1.0")
        connection.connectTimeout = 10_000
        connection.readTimeout = 10_000
        return connection.inputStream.bufferedReader().use { it.readText() }
    }

    suspend fun fetchTrending(): List<DiscoverBook> = withContext(Dispatchers.IO) {
        runCatching {
            val json = JSONObject(fetchJson("https://openlibrary.org/trending/daily.json?limit=20"))
            val works = json.getJSONArray("works")
            (0 until works.length()).map { i ->
                val w = works.getJSONObject(i)
                val title = w.optString("title", "Tanpa judul")
                val author = w.optJSONArray("author_name")?.optString(0) ?: "Tidak diketahui"
                val coverId = w.optInt("cover_i", -1)
                val coverUrl = if (coverId > 0) "https://covers.openlibrary.org/b/id/$coverId-M.jpg" else null
                val key = w.optString("key", "")
                DiscoverBook(
                    title = title,
                    author = author,
                    coverUrl = coverUrl,
                    source = "Trending • Open Library",
                    detailUrl = "https://openlibrary.org$key"
                )
            }
        }.getOrElse { emptyList() }
    }

    suspend fun fetchPopularPublicDomain(): List<DiscoverBook> = withContext(Dispatchers.IO) {
        runCatching {
            val json = JSONObject(fetchJson("https://gutendex.com/books/?sort=popular"))
            val results = json.getJSONArray("results")
            (0 until minOf(results.length(), 20)).mapNotNull { i ->
                val b = results.getJSONObject(i)
                val title = b.optString("title", "Tanpa judul")
                val authors = b.optJSONArray("authors")
                val author = if (authors != null && authors.length() > 0) {
                    authors.getJSONObject(0).optString("name", "Tidak diketahui")
                } else "Tidak diketahui"
                val formats = b.optJSONObject("formats") ?: return@mapNotNull null
                val epubUrl = formats.optString("application/epub+zip", "").takeIf { it.isNotBlank() }
                val coverUrl = formats.optString("image/jpeg", "").takeIf { it.isNotBlank() }
                val gutenbergId = b.optInt("id", 0)
                DiscoverBook(
                    title = title,
                    author = author,
                    coverUrl = coverUrl,
                    source = "Domain Publik • Project Gutenberg",
                    detailUrl = "https://www.gutenberg.org/ebooks/$gutenbergId",
                    downloadEpubUrl = epubUrl
                )
            }
        }.getOrElse { emptyList() }
    }
}
