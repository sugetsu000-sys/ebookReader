package com.ebookreader.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ebookreader.app.data.AppDatabase
import com.ebookreader.app.data.BookEntity
import com.ebookreader.app.data.BookmarkEntity
import com.ebookreader.app.parser.EpubParser
import com.ebookreader.app.repository.BookRepository
import com.ebookreader.app.translate.TranslationHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

class ReaderViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = BookRepository(AppDatabase.getInstance(application))

    private val _book = MutableStateFlow<BookEntity?>(null)
    val book: StateFlow<BookEntity?> = _book.asStateFlow()

    private val _chapterTexts = MutableStateFlow<List<String>>(emptyList())
    val chapterTexts: StateFlow<List<String>> = _chapterTexts.asStateFlow()

    private val _translatedText = MutableStateFlow<String?>(null)
    val translatedText: StateFlow<String?> = _translatedText.asStateFlow()

    private val _isTranslating = MutableStateFlow(false)
    val isTranslating: StateFlow<Boolean> = _isTranslating.asStateFlow()

    fun loadBook(bookId: Long) {
        viewModelScope.launch {
            val b = repository.getBook(bookId) ?: return@launch
            _book.value = b
            when (b.format) {
                "epub" -> {
                    val file = File(b.filePath)
                    val (_, chapters) = EpubParser.readSpine(file)
                    _chapterTexts.value = chapters.map { EpubParser.readChapterText(file, it.href) }
                }
                "txt" -> _chapterTexts.value = listOf(runCatching { File(b.filePath).readText() }.getOrDefault(""))
            }
            repository.updateBook(b.copy(lastOpened = System.currentTimeMillis()))
        }
    }

    fun updateProgress(position: Int, pageIndex: Int = 0) {
        val current = _book.value ?: return
        viewModelScope.launch {
            val updated = current.copy(lastPosition = position, lastPageIndex = pageIndex)
            repository.updateBook(updated)
            _book.value = updated
        }
    }

    fun addBookmark(position: Int, pageIndex: Int, label: String) {
        val b = _book.value ?: return
        viewModelScope.launch {
            repository.addBookmark(BookmarkEntity(bookId = b.id, position = position, pageIndex = pageIndex, label = label))
        }
    }

    fun bookmarks(bookId: Long) = repository.getBookmarks(bookId)

    fun translateSelection(text: String, sourceLang: String, targetLang: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            _isTranslating.value = true
            _translatedText.value = runCatching {
                TranslationHelper.translate(text, sourceLang, targetLang)
            }.getOrElse { "Gagal menerjemahkan: ${it.message}" }
            _isTranslating.value = false
        }
    }

    fun clearTranslation() {
        _translatedText.value = null
    }
}
