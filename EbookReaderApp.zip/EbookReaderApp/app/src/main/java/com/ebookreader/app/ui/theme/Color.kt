package com.ebookreader.app.ui.theme

import androidx.compose.ui.graphics.Color

val SepiaBackground = Color(0xFFF4ECD8)
val SepiaText = Color(0xFF3B2F2F)
val NightBackground = Color(0xFF121212)
val NightText = Color(0xFFE0E0E0)
val AccentBrown = Color(0xFF8D6E63)
